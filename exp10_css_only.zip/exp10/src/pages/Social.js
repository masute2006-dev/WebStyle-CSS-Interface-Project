import { useState, useEffect } from "react";
import axios from "axios";

function Social() {
  const [text, setText] = useState("");
  const [posts, setPosts] = useState([]);

  const API = "http://localhost:5000/social";

  useEffect(() => {
    axios.get(API).then((res) => setPosts(res.data));
  }, []);

  function addPost() {
    if (text === "") return;

    axios.post(API, { text }).then((res) => {
      setPosts([res.data, ...posts]);
      setText("");
    });
  }

  function likePost(id) {
    axios.put(`${API}/${id}`).then(() => {
      setPosts(
        posts.map((p) =>
          p._id === id ? { ...p, likes: p.likes + 1 } : p
        )
      );
    });
  }

  function deletePost(id) {
    axios.delete(`${API}/${id}`).then(() => {
      setPosts(posts.filter((p) => p._id !== id));
    });
  }

  return (
    <div style={styles.container}>
      
      <h2 style={styles.title}>💬 Social Feed</h2>

      {/* Input box */}
      <div style={styles.inputBox}>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="What's on your mind?"
          style={styles.input}
        />

        <button onClick={addPost} style={styles.postBtn}>
          Post
        </button>
      </div>

      {/* Posts */}
      <div style={styles.feed}>
        {posts.map((item) => (
          <div key={item._id} style={styles.card}>
            
            <p style={styles.text}>{item.text}</p>

            <div style={styles.actions}>
              
              <button
                onClick={() => likePost(item._id)}
                style={styles.likeBtn}
              >
                ❤️ {item.likes}
              </button>

              <button
                onClick={() => deletePost(item._id)}
                style={styles.deleteBtn}
              >
                🗑 Delete
              </button>

            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Social;

// ================= STYLES =================
const styles = {
  container: {
    maxWidth: "600px",
    margin: "40px auto",
    fontFamily: "Arial",
  },

  title: {
    textAlign: "center",
    marginBottom: "20px",
  },

  inputBox: {
    display: "flex",
    gap: "10px",
    marginBottom: "20px",
  },

  input: {
    flex: 1,
    padding: "10px",
    borderRadius: "8px",
    border: "1px solid #ccc",
    outline: "none",
  },

  postBtn: {
    padding: "10px 15px",
    background: "#4f46e5",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
  },

  feed: {
    display: "flex",
    flexDirection: "column",
    gap: "15px",
  },

  card: {
    padding: "15px",
    borderRadius: "12px",
    background: "#fff",
    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
  },

  text: {
    fontSize: "16px",
    marginBottom: "10px",
  },

  actions: {
    display: "flex",
    justifyContent: "space-between",
  },

  likeBtn: {
    background: "#fef2f2",
    border: "none",
    padding: "6px 10px",
    borderRadius: "8px",
    cursor: "pointer",
  },

  deleteBtn: {
    background: "#fee2e2",
    border: "none",
    padding: "6px 10px",
    borderRadius: "8px",
    cursor: "pointer",
  },
};
