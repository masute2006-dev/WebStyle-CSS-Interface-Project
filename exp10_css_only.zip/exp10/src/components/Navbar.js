import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div style={{
      padding: "15px",
      background: "#333",
      color: "white",
      display: "flex",
      gap: "15px"
    }}>
      <Link to="/" style={{ color: "white" }}>Todo</Link>
      <Link to="/blog" style={{ color: "white" }}>Blog</Link>
      <Link to="/social" style={{ color: "white" }}>Social</Link>
      <Link to="/login" style={{ color: "white" }}>Login</Link>
      <Link to="/register" style={{ color: "white" }}>Register</Link>
    </div>
  );
}

export default Navbar;
