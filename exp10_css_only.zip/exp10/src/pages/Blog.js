import { useState, useEffect } from "react";
import axios from "axios";

function Blog() {

  const [text, setText] = useState("");
  const [posts, setPosts] = useState([]);

  const API = "http://localhost:5000/posts";

  function getPosts() {
    axios.get(API).then(res => setPosts(res.data));
  }

  useEffect(() => {
    getPosts();
  }, []);

  function addPost() {
    if (text === "") return;

    axios.post(API, { text }).then(() => {
      setText("");
      getPosts();
    });
  }

  function deletePost(id) {
    axios.delete(`${API}/${id}`).then(() => {
      getPosts();
    });
  }

  return (
    <div style={{ padding: "20px" }}>

      <h2>Blog</h2>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Write post"
      />

      <button onClick={addPost}>Post</button>

      {posts.map((item) => (
        <div key={item._id} style={{ marginTop: "10px" }}>

          <span>{item.text}</span>

          <button onClick={() => deletePost(item._id)}> ❌ </button>

        </div>
      ))}

    </div>
  );
}

export default Blog;
