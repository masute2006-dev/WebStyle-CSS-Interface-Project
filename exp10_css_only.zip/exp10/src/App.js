import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Todo from "./pages/Todo";
import Blog from "./pages/Blog";
import Social from "./pages/Social";


function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Todo />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/social" element={<Social />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
