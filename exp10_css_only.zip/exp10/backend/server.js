const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();

// ================= MIDDLEWARE =================
app.use(express.json());

// FIXED CORS (important for React frontend)
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);

// ================= MONGOOSE =================
mongoose
  .connect("mongodb://127.0.0.1:27017/todoDB")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("Mongo Error:", err));

// ================= MODELS =================
const Todo = mongoose.model("Todo", {
  text: String,
  done: Boolean,
});

const Post = mongoose.model("Post", {
  text: String,
});

const Social = mongoose.model("Social", {
  text: String,
  likes: Number,
});

const User = mongoose.model("User", {
  username: String,
  password: String,
});

// ================= AUTH =================

// REGISTER
app.post("/register", async (req, res) => {
  try {
    const hashed = await bcrypt.hash(req.body.password, 10);

    const user = new User({
      username: req.body.username,
      password: hashed,
    });

    await user.save();
    res.json({ message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// LOGIN
app.post("/login", async (req, res) => {
  try {
    const user = await User.findOne({ username: req.body.username });

    if (!user) return res.status(404).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(req.body.password, user.password);

    if (!isMatch)
      return res.status(400).json({ message: "Wrong password" });

    const token = jwt.sign({ id: user._id }, "secret", {
      expiresIn: "1d",
    });

    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================= TODO =================

// CREATE
app.post("/todos", async (req, res) => {
  const todo = new Todo({
    text: req.body.text,
    done: false,
  });

  await todo.save();
  res.json(todo);
});

// READ
app.get("/todos", async (req, res) => {
  const todos = await Todo.find();
  res.json(todos);
});

// UPDATE
app.put("/todos/:id", async (req, res) => {
  const todo = await Todo.findById(req.params.id);

  if (!todo) return res.status(404).json({ message: "Todo not found" });

  todo.done = !todo.done;
  await todo.save();

  res.json(todo);
});

// DELETE
app.delete("/todos/:id", async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

// ================= BLOG =================

// CREATE
app.post("/posts", async (req, res) => {
  const post = new Post({ text: req.body.text });
  await post.save();
  res.json(post);
});

// READ
app.get("/posts", async (req, res) => {
  const posts = await Post.find();
  res.json(posts);
});

// DELETE
app.delete("/posts/:id", async (req, res) => {
  await Post.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

// ================= SOCIAL =================

// CREATE
app.post("/social", async (req, res) => {
  const post = new Social({
    text: req.body.text,
    likes: 0,
  });

  await post.save();
  res.json(post);
});

// READ
app.get("/social", async (req, res) => {
  const posts = await Social.find();
  res.json(posts);
});

// LIKE
app.put("/social/:id", async (req, res) => {
  const post = await Social.findById(req.params.id);

  if (!post) return res.status(404).json({ message: "Not found" });

  post.likes += 1;
  await post.save();

  res.json(post);
});

// DELETE
app.delete("/social/:id", async (req, res) => {
  await Social.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

// ================= SERVER =================
const PORT = 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
