import { useState, useEffect } from "react";
import axios from "axios";

function Todo() {

  const [text, setText] = useState("");
  const [list, setList] = useState([]);

  const API = "http://localhost:5000/todos";

  function getTodos() {
    axios.get(API).then(res => setList(res.data));
  }

  useEffect(() => {
    getTodos();
  }, []);

  function addTask() {
    if (text === "") return;

    axios.post(API, { text }).then(() => {
      setText("");
      getTodos();
    });
  }

  function toggleTask(id) {
    axios.put(`${API}/${id}`).then(() => getTodos());
  }

  function deleteTask(id) {
    axios.delete(`${API}/${id}`).then(() => getTodos());
  }

  return (
    <div style={{
      padding: "20px",
      maxWidth: "500px",
      margin: "auto"
    }}>

      <h2>MERN Todo</h2>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter task"
      />

      <button onClick={addTask}>Add</button>

      {list.map((item) => (
        <div
          key={item._id}
          style={{
            background: "white",
            padding: "10px",
            marginTop: "10px",
            borderRadius: "8px",
            boxShadow: "0 2px 5px rgba(0,0,0,0.1)"
          }}
        >

          <span
            onClick={() => toggleTask(item._id)}
            style={{
              textDecoration: item.done ? "line-through" : "none",
              cursor: "pointer",
              marginRight: "10px"
            }}
          >
            {item.text}
          </span>

          <button
            onClick={() => deleteTask(item._id)}
            style={{ background: "red" }}
          >
            ❌
          </button>

        </div>
      ))}

    </div>
  );
}

export default Todo;
